import numpy as np
from fct_chim import *
from covmat2cormat import *

print("Méthodes d'estimation, SIE 3e semestre, GC 5e semestre")
print('Propriétés de composants organiques')
print('Compensation conditionnelle pour un composant','\n')

# Préambule

# Dans la publication citée, voici les valeurs compensées pour PCB-3, sous
# forme de logarithmes décimaux.

# log10 SAL = -3.75 (mol/m3)
# log10 SWL = -1.70 (mol/m3)
# log10 SOL =  3.01 (mol/m3)
# log10 KAW = -2.06 (-)
# log10 KOW =  4.71 (-)
# log10 KOA =  6.77 (-)

# Le même article mentionne le coefficient de fugacité, mais ne donne pas
# de valeur numérique. J'en ai choisi une pour calculer des observations de
# SAS, SWS et SOS.

# Les hypothèses pour le modèle stochastique n'étaient pas explicites. J'ai
# donc choisi des valeurs vraisemblables.

# Dans le contexte de ce cours, voici les points cruciaux de cet exercice:

# - le nombre de conditions,
# - l'usage conjoint de deux types de conditions,
# - les alternatives pour linéariser,
# - la compréhension des résultats, notamment du quotient global.

# Si un-e spécialiste s'annonce pour améliorer l'application numérique,
# c'est très volontiers!

# BM 03.11.21

# =========================================================================

# Pour tenir compte des ordres de grandeurs différents à l'intérieur des
# vecteurs et des matrices, on impose des exposants individuels.

np.set_printoptions(precision=4, suppress=False)

# DONNEES

# 1. Mesures pour PCB-3

SAS = 126e-5     # mol/m3
SAL = 178e-6     # mol/m3
SWS = 145e-3     # mol/m3
SWL = 200e-4     # mol/m3
SOS = 696e1      # mol/m3
SOL = 102e1      # mol/m3
logKAW = -2.16   # sans dimension
logKOW =  4.82   # sans dimension
logKOA =  6.66   # sans dimension

# 2. Ecarts-types (a priori)

sigmarelS = 0.03   # valeur relative (3%)
sigmalogK = 0.1    # valeur absolue

print('sigmarelS =',sigmarelS,'\n')
print('sigmalogK =',sigmalogK,'\n')

# Formation du vecteur des observations
# L'ordre est arbitraire, mais il doit être respecté dans B et dans Kll.
# On forme un vecteur-colonne.

obs = np.array([[SAS, SAL, SWS, SWL, SOS, SOL, logKAW, logKOW, logKOA]]).T
n = len(obs)

print('obs =',obs,'\n')

# =========================================================================

# MODELE FONCTIONNEL

# 1. Surdétermination

# Dans ce corrigé, on suit rigoureusement la démarche générale "poser le
# problème" présentée lors du cours. Pour déterminer r, on a plusieurs
# options.

# a) Compter les observations surabondantes
# On regarde combien d'observations sont nécessaires pour calculer les
# autres. Par exemple, à partir de SAS, SAL, SWS et SOS, on peut déduire
# les 5 autres, donc on peut poser 5 conditions. Cela n'irait pas avec SAS,
# SAL, SWS et SWL, mais ce n'est pas parce des bêtises sont possibles que
# l'on est obligé de les faire.

# b) Poser les conditions
# On peut aussi écrire des relations jusqu'à ne plus pouvoir en exprimer
# une nouvelle que l'on ne peut pas déduire des précédentes. Dans ce cas,
# on établit r et w conjointement.

# c) Au delà du nombre
# Généralement, on peut exprimer des conditions équivalentes de façons
# différentes. Lorsque plusieurs chemins conduisent au même résultat, un-e
# ingénieur-e doit choisir le plus direct (contrairement au touriste).

# d) Moralité
# Il n'existe aucune recette applicable dans tous les contextes. Des
# préférences personnelles pour l'un ou l'autre type de raisonnement sont
# possibles.

r = 5

# 2. Conditions (partiellement) indépendantes et écarts de fermeture

w = fct_chimie(r,obs)

print('w =',w,'\n')

# 3. Linéarisation du modèle fonctionnel

# construction de la matrice des dérivées partielles B

B = np.zeros([r,n])

# variante numérique

# Au vu des grandeurs très diverses des observations, l'usage d'un
# incrément uniforme est à proscrire. Pour chaque observation, l'incrément
# choisi correspond à sa dernière décimale. Ce choix, plutôt qu'un lien
# avec sigma, peut surprendre. Dans un monde raisonnable, la dernière
# décimale est du même ordre de grandeur que sigma.

inc = [1e-5, 1e-6, 1e-3, 1e-4, 1e1, 1e1, 0.01, 0.01, 0.01]

for j in range(9):

	# remise des observations à leurs valeurs initiales, puis incrémentation
	# d'une observation, à tour de rôle

	obsinc = obs.copy()
	obsinc[j,0] = obs[j,0]+inc[j]

	# vecteur des écarts de fermeture avec une observation incrémentée
	winc = fct_chimie(r,obsinc)

	# C'est parti pour toute une colonne de dérivées partielles.

	B[:,j] = np.ndarray.flatten((winc-w)/inc[j])

# variante analytique
# C'est difficile de construire B de façon systématique, alors restons dans
# le domaine artisanal. La démarche est utile pour contrôler la
# linéarisation numérique ... et réciproquement!

# B[0,0]=SWL
# B[0,1]=-SWS
# B[0,2]=-SAL
# B[0,3]=SAS

# B[1,0]=SOL
# B[1,1]=-SOS
# B[1,4]=-SAL
# B[1,5]=SAS

# tralog=log(10)    % pour les dérivées des log10

# B[2,1]=1/SAL/tralog
# B[2,3]=-1/SWL/tralog
# B[2,6]=-1

# B[3,1]=1/SAL/tralog
# B[3,5]=-1/SOL/tralog
# B[3,8]=1

# B[4,3]=1/SWL/tralog
# B[4,5]=-1/SOL/tralog
# B[4,7]=1

print('B =', B,'\n')

# =========================================================================

# MODELE STOCHASTIQUE

# Comme on a 2 types d'observations, avec des unités différentes, on
# renonce à l'usage de cofacteurs. On construit la matrice de covariance
# des observations en plaçant la variance de chaque observation sur la
# diagonale.

Kll = np.zeros([n,n])
# écarts-types des solubilités
sigmaS = sigmarelS*np.array([SAS, SAL, SWS, SWL, SOS, SOL])
Kll[0:6,0:6] = np.diag(sigmaS*sigmaS)  # produit élément par élément
np.fill_diagonal(Kll[6:9,6:9],sigmalogK*sigmalogK*np.ones([1,3]))

print('Kll =',Kll,'\n')

# =========================================================================

# COMPENSATION

Aux1 = Kll@B.T
Aux2 = Aux1@np.linalg.inv(B@Aux1)

# 1. résidus compensés (v_chapeau)

vcomp = Aux2@w

print('vcomp =', vcomp,'\n')
# 2. observations compensées (l_chapeau)

lcomp = obs-vcomp

print('lcomp =', lcomp,'\n')
# CONTROLE
# Les écarts de fermeture compensés ne sont pas nuls, mais ils doivent
# être significativement plus petits que les originaux.
# La fonction s'avère à nouveau bien utile.

wcomp = fct_chimie(r,lcomp)

print('wcomp =', wcomp,'\n')

# =========================================================================

# DESCRIPTION DES RESULTATS

# covariance des résidus compensés

Kvcomp = Aux2@Aux1.T

# Interpréter une matrice de covariance est assez difficile. Mieux vaut
# extraire les écart-types et les corrélations, comme d'habitude!

[sigmavcomp,Rvcomp] = covmat2cormat(Kvcomp)

# écarts-types imprimés en colonne
print('sigmavcomp =',np.array([sigmavcomp]).T,'\n')

# corrélations imprimées avec 2 décimales (pour-cents)
np.set_printoptions(precision=2, suppress=True)
print('Rvcomp =',Rvcomp,'\n')

# covariance des observations compensées

Klcomp = Kll - Kvcomp

[sigmalcomp,Rlcomp] = covmat2cormat(Klcomp)

np.set_printoptions(precision=4, suppress=False)
print('sigmalcomp =',np.array([sigmalcomp]).T,'\n')
np.set_printoptions(precision=2, suppress=True)
print('Rlcomp =',Rlcomp,'\n')

# estimation de la précision

P = np.linalg.inv(Kll) 
QuotientGlobal = np.sqrt((vcomp.T@P@vcomp)/r)

print('QuotientGlobal =',QuotientGlobal,'\n')

# =========================================================================

# Anticipons dans le cours: théorie de la fiabilité
# Comme pour le gaz parfait, on peut calculer un quotient d'erreur pour
# chaque type d'observations.
# part de redondance de chaque observation

z = np.array([np.diag(Kvcomp@P)]).T # vecteur-colonne
sumz = sum(z)

print('z =',z,'\n')
print('sumz =',sumz,'\n')

# quotient d'erreur moyenne pour les solubilités
vS = vcomp[0:6,0]
zS = z[0:6]
QuotientS = np.sqrt((vS.T@P[0:6,0:6]@vS)/sum(zS))
print('QuotientS =%.2f'%QuotientS,'\n')

# quotient d'erreur moyenne pour les log des coefficients de partition
vlogK = vcomp[6:9,0]
zlogK = z[6:9]
QuotientlogK = np.sqrt((vlogK.T@P[6:9,6:9]@vlogK)/sum(zlogK))
print('QuotientlogK =%.2f'%QuotientlogK,'\n')