import math
import numpy as np

def fct_chimie(r,obs):

	# CHIMIE COMPUTATIONNELLE
	# conditions = calcul des écarts de fermeture

	SAS = obs[0,0]
	SAL = obs[1,0]
	SWS = obs[2,0]
	SWL = obs[3,0]
	SOS = obs[4,0]
	SOL = obs[5,0]
	logKAW = obs[6,0]
	logKOW = obs[7,0]
	logKOA = obs[8,0]

	w = np.zeros([r,1])

	# L'égalité des quotients de fugacité dans les 3 expressions permet de
	# poser 2 conditions, par exemple:

	w[0,0] = SAS*SWL - SAL*SWS
	w[1,0] = SAS*SOL - SAL*SOS

	# Alternative
	# w[0,0] = math.log10(SAS) - math.log10(SAL) - math.log10(SWS) + math.log10(SWL)
	# w[1,0] = math.log10(SAS) - math.log10(SAL) - math.log10(SOS) + math.log10(SOL)
	# C'est équivalent, mais il faut adapter la matrice B.

	# Pour chaque coefficient de partition, on dispose d'une détermination
	# directe et d'une détermination indirecte. Seules 3 des 4 dernières
	# conditions de l'énoncé sont indépendantes. La relation entre les 3
	# coefficients de partition découle des 3 conditions suivantes.

	w[2,0] = math.log10(SAL) - math.log10(SWL) - logKAW
	w[3,0] = math.log10(SAL) - math.log10(SOL) + logKOA
	w[4,0] = math.log10(SWL) - math.log10(SOL) + logKOW

	return w